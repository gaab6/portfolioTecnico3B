package com.example.estatistica;

public class Aluno {
    String nome;
    int matricula;
    int idade;
    float nota;

    public Aluno(String nome, int matricula, int idade, float nota) {
        this.nome = nome;
        this.matricula = matricula;
        this.idade = idade;
        this.nota = nota;
    }

}
