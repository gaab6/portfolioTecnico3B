package com.example.estatistica;

import java.util.ArrayList;

public class Repositorio {
    ArrayList <Aluno> alunos = new ArrayList<Aluno>();
}
